-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: 127.0.0.1    Database: cantine
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PARENT`
--

DROP TABLE IF EXISTS `PARENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PARENT` (
  `PARENT_ID` int NOT NULL,
  `FIRST_NAME` varchar(45) NOT NULL,
  `LAST_NAME` varchar(45) NOT NULL,
  `SEXE` varchar(45) NOT NULL,
  `DATE_NAISSANCE` varchar(45) NOT NULL,
  `MOT_PASSE` varchar(45) NOT NULL,
  `LOGIN` varchar(45) NOT NULL,
  PRIMARY KEY (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PARENT`
--

LOCK TABLES `PARENT` WRITE;
/*!40000 ALTER TABLE `PARENT` DISABLE KEYS */;
INSERT INTO `PARENT` VALUES (1,'Jean-Robert','Lapp','Homme','16/07/1980','Logh796UC','JR'),(2,'Jessica','Edwards','Femme','26/12/1980','Logh797UC','JE'),(3,'Yang','Wen-Li','Homme','11/08/1980','Logh800UC','YW'),(4,'Frederica','Greenhill','Femme','04/02/1986','Logh801UC','FG'),(5,'Reinhard','Lohengramm','Homme','17/05/1984','Logh776UC','RL'),(6,'Hilda','Mariendorf','Femme','28/05/1985','Logh777UC','HM'),(7,'Wolf','Mittermeyer','Homme','12/07/1980','Logh780UC','WM'),(8,'Evangeline','Mittermeyer','Femme','16/12/1986','Logh781UC','EM'),(9,'Alex','Cazerne','Homme','20/01/1980','Logh778UC','AC'),(10,'Hortense','Cazerne','Femme','08/08/1982','Logh779UC','HC'),(11,'Gendo','Ikari','Homme','01/01/1980','Eva01','GI'),(12,'Yui','Ikari','Femme','30/01/1980','Eva02','YI'),(13,'Mathieu','Jasmin','Homme','19/09/1980','Zelda2023','MJ'),(14,'Maly','Jasmin','Femme','10/10/1981','Royal891','MaJ'),(15,'Dominique','Sean','Homme','07/07/1981','Club187','DS'),(16,'Marie','Sean','Femme','02/02/1982','Marvel718','MS'),(17,'Frederic','Hong','Homme','21/07/1990','Lol119','FH'),(18,'Julie','Hong','Femme','13/04/1990','Cat871','JH'),(19,'Nino','Grassin','Homme','25/03/1991','Hand1991','NG'),(20,'Alyssa','Grassin','Femme','18/09/1992','DC908','AG');
/*!40000 ALTER TABLE `PARENT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-12 20:06:39
